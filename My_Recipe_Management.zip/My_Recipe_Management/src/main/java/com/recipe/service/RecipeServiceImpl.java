package com.recipe.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recipe.custom_exception.ResourceNotFoundException;
import com.recipe.dto.ApiResponse;
import com.recipe.dto.RecipeDto;
import com.recipe.entities.Recipe;
import com.recipe.repository.RecipeRepository;

@Service
@Transactional
public class RecipeServiceImpl implements RecipeService {

	@Autowired
	private RecipeRepository recipeRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public ApiResponse addRecipe(RecipeDto dto) {
		Recipe recipe=mapper.map(dto, Recipe.class);
		recipeRepo.save(recipe);
		return new ApiResponse("Recipe added successfully");
	}

	@Override
	public RecipeDto getRecipe(Long id) {
		Recipe recipe=recipeRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Invalid id"));
		RecipeDto dto=mapper.map(recipe, RecipeDto.class);
		return dto;
	}

	@Override
	public ApiResponse updateRecipe(Long id, RecipeDto dto) {
		String mesg="Updation failed";
		Recipe recipe=recipeRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Invalid Id"));
		mapper.map(dto, recipe);
//		recipeRepo.save(recipe);
		mesg="Updated successfully";
		return new ApiResponse(mesg);
	}

	@Override
	public ApiResponse deleteRecipe(Long id) {
		String mesg="Deletion failed";
		Recipe recipe=recipeRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Invalid Id"));
		recipeRepo.delete(recipe);
		mesg="Deleted successfully";
		return new ApiResponse(mesg);
		
	}

	@Override
	public List<RecipeDto> getRecipes() {
		return recipeRepo.findAll().stream()
				.map(recipe->mapper.map(recipe, RecipeDto.class))
				.collect(Collectors.toList());
	}

}
