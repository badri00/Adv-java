package com.recipe.service;

import java.util.List;

import com.recipe.dto.ApiResponse;
import com.recipe.dto.RecipeDto;
import com.recipe.entities.Recipe;

public interface RecipeService {

	ApiResponse addRecipe(RecipeDto dto);

	RecipeDto getRecipe(Long id);

	ApiResponse updateRecipe(Long id, RecipeDto dto);

	ApiResponse deleteRecipe(Long id);

	List<RecipeDto> getRecipes();

}
