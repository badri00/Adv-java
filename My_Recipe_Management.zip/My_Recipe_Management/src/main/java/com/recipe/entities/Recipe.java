package com.recipe.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="recipe")
public class Recipe extends BaseEntity{
	
	private String title;
	private String description;
	private String ingredients;
	private String instructions;
	
	@Column(name="difficulty_level")
	private int difficultyLevel;
	
	@Column(name="cuisine_type")
	private String cuisineType;
	
//	@ManyToOne
//	@JoinColumn(name = "author_id", nullable=false)
//	private Author author;

	public Recipe(String title, String description, String ingredients, String instructions, int difficultyLevel,
			String cuisineType) {
		super();
		this.title = title;
		this.description = description;
		this.ingredients = ingredients;
		this.instructions = instructions;
		this.difficultyLevel = difficultyLevel;
		this.cuisineType = cuisineType;
	}
	
	
	
}
