package com.recipe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.dto.RecipeDto;
import com.recipe.service.RecipeService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("/recipe")
public class RecipeController {

	@Autowired
	private RecipeService recipeService;
	
	@PostMapping
	ResponseEntity<?> addNewRecipe(@RequestBody RecipeDto dto){
		System.out.println("In post mapping adding recipe");
		return ResponseEntity.status(HttpStatus.CREATED).body(recipeService.addRecipe(dto));
	}
	
	@GetMapping("/{id}")
	ResponseEntity<?> getRecipeById(@PathVariable Long id){
		System.out.println("In get mapping by id");
		return ResponseEntity.ok(recipeService.getRecipe(id));
	}
	
	@GetMapping("/list")
	ResponseEntity<?> getAllRecipe(){
		System.out.println("In get all recipes");
		return ResponseEntity.ok(recipeService.getRecipes());
	}
	
	@PutMapping("/{id}")
	@Operation(description = "Update Recipe details")
	ResponseEntity<?> updateRecipeById(@PathVariable Long id, @RequestBody RecipeDto dto){
		System.out.println("In post mapping updating recipe");
		return ResponseEntity.status(HttpStatus.OK).body(recipeService.updateRecipe(id,dto));
	}
	
	@DeleteMapping("/{id}")
	@Operation(description = "Update Recipe details")
	ResponseEntity<?> deleteRecipeById(@PathVariable Long id){
		System.out.println("In delete mapping");
		return ResponseEntity.ok(recipeService.deleteRecipe(id));
	}
}
