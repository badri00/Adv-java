package com.recipe.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class RecipeDto extends BaseEntityDto {

	private String title;
	private String description;
	private String ingredients;
	private String instructions;
	private int difficultyLevel;
	private String cuisineType;
}
