package com.vehicle.service;

import java.util.List;

import com.vehicle.dto.ApiResponse;
import com.vehicle.dto.VehicleDto;
import com.vehicle.entities.Vehicle;

public interface VehicleService {

	ApiResponse addVehicle(VehicleDto dto);

	List<Vehicle> getVehicles(String user_name);

	ApiResponse deleteVehicle(String user_name);
}
