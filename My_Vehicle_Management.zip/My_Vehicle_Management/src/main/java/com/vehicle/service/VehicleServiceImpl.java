package com.vehicle.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicle.custom_exception.ResourceNotFoundException;
import com.vehicle.dto.ApiResponse;
import com.vehicle.dto.VehicleDto;
import com.vehicle.entities.User;
import com.vehicle.entities.Vehicle;
import com.vehicle.repository.UserRepository;
import com.vehicle.repository.VehicleRepository;

@Service
@Transactional
public class VehicleServiceImpl implements VehicleService {

	@Autowired
	private VehicleRepository vehicleRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public ApiResponse addVehicle(VehicleDto dto) {
		User user=userRepo.findById(dto.getUserId()).orElseThrow(()->new ResourceNotFoundException("Invalid user id"));
		Vehicle vehicle=mapper.map(dto, Vehicle.class);
		vehicle.setUser(user);
		vehicleRepo.save(vehicle);
		return new ApiResponse("Vehicle added successfully");
	}

	@Override
	public List<Vehicle> getVehicles(String user_name) {
		
		return vehicleRepo.findByUserUserName(user_name).stream().map((s)->mapper.map(s,Vehicle.class))
				.collect(Collectors.toList());
	}

	@Override
	public ApiResponse deleteVehicle(String user_name) {
		List<Vehicle> vehicles=vehicleRepo.findByUserUserName(user_name).stream().map((s)->mapper.map(s,Vehicle.class))
				.collect(Collectors.toList());
		vehicles.forEach(v->vehicleRepo.delete(v));
		return new ApiResponse("Vehicle deleted successfully");
	}

}
