package com.vehicle.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="vehicles")
public class Vehicle extends BaseEntity {

	@Column(name="vehicle_name")
	private String vehicleName;
	
	@Enumerated(EnumType.STRING)
	private Company company;
	
	@Column(name="vehicle_no")
	private String vehicleNumber;
	
	@Column(name="vehicle_type")
	private String vehicleType;
	
	@ManyToOne
	@JoinColumn(name="user_id", nullable=false)
	private User user;

	public Vehicle(String vehicleName, Company company, String vehicleNumber, String vehicleType) {
		super();
		this.vehicleName = vehicleName;
		this.company = company;
		this.vehicleNumber = vehicleNumber;
		this.vehicleType = vehicleType;
	}
	

	
	
}
