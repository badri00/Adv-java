package com.vehicle.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name="users")
public class User extends BaseEntity {

	@Column(name="user_name")
	private String userName;
	
	private String email;
	
	private String password;
	
	private String city;
	
	@Column(name="contact")
	private String contactNo;

	public User(String userName, String email, String city, String contactNo) {
		super();
		this.userName = userName;
		this.email = email;
		this.city = city;
		this.contactNo = contactNo;
	}
	
}
