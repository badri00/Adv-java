package com.vehicle.entities;

public enum Company {

	HERO, HONDA, BAJAJ
}
