package com.vehicle.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vehicle.dto.VehicleDto;
import com.vehicle.service.VehicleService;

@RestController
@RequestMapping("/vehicles")
public class VehicleController {

	@Autowired
	private VehicleService service;
	
	@PostMapping
	ResponseEntity<?> addNewVehicle(@RequestBody VehicleDto dto){
		System.out.println("In post mapping add vehicle");
		return ResponseEntity.status(HttpStatus.CREATED).body(service.addVehicle(dto));
	}
	
	@GetMapping("/{user_name}")
	ResponseEntity<?> getAllVehicles(@PathVariable String user_name){
		System.out.println("In get mapping get all vehicles");
		return ResponseEntity.ok(service.getVehicles(user_name));
	}
	
	@DeleteMapping("/{user_name}")
	ResponseEntity<?> deleteVehicle(@PathVariable String user_name){
		System.out.println("In delete mapping");
		return ResponseEntity.ok(service.deleteVehicle(user_name));
	}
	
}
