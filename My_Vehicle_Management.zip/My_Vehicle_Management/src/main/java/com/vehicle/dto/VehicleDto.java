package com.vehicle.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.vehicle.entities.Company;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class VehicleDto extends BaseEntityDto {

	private String vehicleName;
	private Company company;
	private String vehicleNumber;
	private String vehicleType;
	@JsonProperty(access=Access.WRITE_ONLY)
	private Long userId;
	
//	public VehicleDto(String vehicleName, Company company, String vehicleNumber, String vehicleType) {
//		super();
//		this.vehicleName = vehicleName;
//		this.company = company;
//		this.vehicleNumber = vehicleNumber;
//		this.vehicleType = vehicleType;
//	}
//	
//	
}
