package com.vehicle.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ApiResponse {

	private String mesg;
	private LocalDateTime updationTime;
	
	public ApiResponse(String mesg) {
		super();
		this.mesg=mesg;
		this.updationTime=LocalDateTime.now();
	}
}
