package com.vehicle.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserDto extends BaseEntityDto {

	private String userName;
	private String email;
	private String password;
	private String city;
	private String contactNo;
	
//	public UserDto(String userName, String email, String city, String contactNo) {
//		super();
//		this.userName = userName;
//		this.email = email;
//		this.city = city;
//		this.contactNo = contactNo;
//	}
	
}
