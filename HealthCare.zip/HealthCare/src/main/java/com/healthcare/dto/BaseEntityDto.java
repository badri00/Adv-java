package com.healthcare.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@NoArgsConstructor
@ToString
public class BaseEntityDto {

   @JsonProperty(access = Access.READ_ONLY)
    private Long id;

   @JsonProperty(access = Access.READ_ONLY)
    private LocalDate creationDate;

   @JsonProperty(access = Access.READ_ONLY)
    private LocalDateTime updateTimestamp;
}
