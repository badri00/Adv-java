package com.healthcare.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "patients")
@Setter
@Getter
@NoArgsConstructor
@ToString
public class Patient extends BaseEntity {
    private String name;
    private String email;
}
