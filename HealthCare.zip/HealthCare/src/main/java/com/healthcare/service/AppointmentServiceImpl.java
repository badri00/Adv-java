package com.healthcare.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.custom_Exception.ResourceNotFoundException;
import com.healthcare.dto.ApiResponse;
import com.healthcare.dto.AppointmentDto;
import com.healthcare.entities.Appointment;
import com.healthcare.entities.Patient;
import com.healthcare.repository.AppointmentRepo;
import com.healthcare.repository.PatientRepo;

@Service
@Transactional
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    private AppointmentRepo appointmentRepo;

    @Autowired
    private PatientRepo patientRepo;

    @Autowired
    private ModelMapper mapper;

    @Override
    public ApiResponse createAppointment(AppointmentDto dto) {
        if (appointmentRepo.existsByDoctorNameAndDateAndTime(dto.getDoctorName(), dto.getDate(), dto.getTime())) {
            throw new ResourceNotFoundException("Appointment slot not available!");
        }

        Patient patient = patientRepo.findById(dto.getPatientId())
            .orElseThrow(() -> new ResourceNotFoundException("Patient not found!"));

        Appointment appointment = mapper.map(dto, Appointment.class);
        appointment.setPatient(patient);
        appointmentRepo.save(appointment);

        return new ApiResponse("Appointment Scheduled Successfully");
    }

    @Override
    public List<AppointmentDto> getUpcomingAppointments(Long patientId) {
        return appointmentRepo.findByPatientId(patientId).stream()
            .map(appointment -> mapper.map(appointment, AppointmentDto.class))
            .collect(Collectors.toList());
    }

    @Override
    public ApiResponse cancelAppointment(Long appointmentId) {
        Appointment appointment = appointmentRepo.findById(appointmentId)
            .orElseThrow(() -> new ResourceNotFoundException("Appointment not found!"));
        appointmentRepo.delete(appointment);
        return new ApiResponse("Appointment Cancelled Successfully");
    }
}
