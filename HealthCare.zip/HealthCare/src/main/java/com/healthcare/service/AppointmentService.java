package com.healthcare.service;

import java.util.List;

import com.healthcare.dto.AppointmentDto;
import com.healthcare.dto.ApiResponse;

public interface AppointmentService {
    ApiResponse createAppointment(AppointmentDto dto);
    List<AppointmentDto> getUpcomingAppointments(Long patientId);
    ApiResponse cancelAppointment(Long appointmentId);
}
